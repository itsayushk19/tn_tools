// eslint-disable-next-line
import EvaluateExpressionWorker from "comlink-loader!./EvaluateExpressionWorker";

export { EvaluateExpressionWorker };
